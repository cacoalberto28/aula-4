# 4-EconometriaAvancada-Aula4
Raizes Unitárias e Teste DF
